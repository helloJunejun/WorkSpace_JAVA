/**
 * 
 */
package com.work.model.dto;

/**
 * @author Playdata
 *
 */
public class SpecialMember extends Member {

}
