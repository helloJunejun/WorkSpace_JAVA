package com.work.model;

import java.util.ArrayList;

import com.work.util.Utility;

/*## JDBC 관련 클래스 의존관계
	1. Test 
	=> MemberService#login(아이디, 비밀번호) : 등급	
	=> MemberDao#login(아이디, 비밀번호):등급
*/
public class MemberService {
	/** MemberDao 객체 */
	//private MemberDao dao = new MemberDao();
	// 4. singleton pattern 반영 객체 인스턴스 가져오기
	private MemberDao dao = MemberDao.getInstance();
	
	/**
	 * 로그인
	 * @param memberId 아이디
	 * @param memberPw 비밀번호
	 * @return 회원 등급, 미존재시 null
	 */
	public String login(String memberId, String memberPw) {
		String grade = dao.login(memberId, memberPw);
		if (grade != null) {
			return grade;
		}
		
		return null;
	}
	
	/**
	 * 회원상세조회 / 내정보조회
	 * @param memberId
	 * @return
	 */
	public Member getMember(String memberId) {
		return dao.selectOne(memberId);
	}
		
	/**
	 * 전체회원조회
	 * @return
	 */
	public ArrayList<Member> getMemberList() {
		return dao.selectList();
	}

	/**
	 * 등급별 전체회원조회
	 * @param grade
	 * @return
	 */
	public ArrayList<Member> getMemberListByGrade(String grade) {
		return dao.selectListByGrade(grade);
	}

	/**
	 * 아이디 찾기
	 * @param name
	 * @param mobile
	 * @return
	 */
	public String findMemberIdByMobile(String name, String mobile) {
		return null;
	}
	
	/**
	 * 아이디 찾기
	 * @param name
	 * @param mobile
	 * @return
	 */
	public String findMemberIdByEmail(String name, String mobile) {
		return null;
	}
	
	/**
	 * 비밀번호 찾기
	 * @param memberId
	 * @param name
	 * @param mobile
	 * @return
	 */
	public String findMemberPwByMobile(String memberId, String name, String mobile) {
		return null;
	}
	
	/**
	 * 비밀번호 찾기 : 코드 구현
	 * 1. dao 해당회원 존재여부 체킹
	 * 2. dao 존재하면
	 * 		2.1 임시암호 발급 : Java Utility 활용
	 * 		2.2 dao 임시암호 변경 요청
	 * 		2.3 임시암호변경 성공 : 임시암호 반환
	 * 3. dao 존재하지 않거나, 임시암호변경 실패시 null 반환
	 * 
	 * @param memberId
	 * @param name
	 * @param mobile
	 * @return
	 */
	public String findMemberPwByEmail(String memberId, String name, String email) {
		if (dao.selectMemberPwByEmail(memberId, name, email)) {
			String tmpMemberPw = Utility.getSecureAlphabetString(10, true, true);
			if(dao.updateMemberPw(memberId, tmpMemberPw)) {
				return tmpMemberPw;
			};
		}
		
		return null;	 
	}
	
	//  : SQL 구문을 먼저 해보세요 (아규먼트로 무엇을 입력받아야할지 생각, 결과는 무엇을 돌려줄지 생각)
	/**
	 * 비밀번호 변경하기
	 * @param memberId
	 * @param memberPw
	 * @param modifyMemberPw
	 * @return 성공 1, 실패 0
	 */
	public int setMemberPw(String memberId, String memberPw, String modifyMemberPw) {
		return dao.updateMemberPw(memberId, memberPw, modifyMemberPw);
	}
	
	
	/**
	 * 아이디 중복여부
	 * @param memberId
	 * @return
	 */
	public boolean existMemberId(String memberId) {
		return dao.selectMemberId(memberId);
	}
	
	/**
	 * 휴대폰 중복여부
	 * @param mobile
	 * @return
	 */
	public boolean existMobile(String mobile) {
		return dao.selectMobile(mobile);
	}
	
	/**
	 * 회원가입 
	 * @return
	 */
	public int addMember(Member dto) {
		if (existMemberId(dto.getMemberId())) {
			System.out.println("[오류] 사용할 수 없는 아이디입니다." + dto.getMemberId());
			return 0;
		}
		
		if (existMobile(dto.getMobile())) {
			System.out.println("[오류] 사용할 수 없는 휴대폰입니다." + dto.getMobile());
			return 0;
		}
		
		return dao.insertMember(dto);
	}

	/**
	 * 회원가입 : 
	 * -- 신입 회원 입력 정보 : 아이디, 비밀번호, 이름, 휴대폰, 이메일
	 * -- 시스템에서 설정 정보 : 가입일, 등급 [, 마일리지]
	 * @param memberId
	 * @param memberPw
	 * @param name
	 * @param mobile
	 * @param email
	 * @return
	 */
	public int addMember(String memberId, String memberPw, String name, String mobile, String email) {
		Member dto = new Member(memberId, memberPw, name, mobile, email);
		dto.setEntryDate(Utility.getCurrentDate());
		dto.setGrade("G");
		dto.setMileage(1000);
		return addMember(dto);
	}
	
}









