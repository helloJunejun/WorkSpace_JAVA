-- drop table
drop table notice purge;
drop table member purge;

-- create table
create table member (
	member_id varchar2(30),
	member_pw varchar2(20) not null,
	name varchar2(20),
	mobile varchar2(13) not null,
	email varchar2(30) not null,
	entry_date varchar2(10) not null,
	grade varchar2(1) not null,
	mileage number(6),
	manager varchar2(20)
);

-- constraint add : pk
alter table member
add constraint pk_memberid primary key (member_id);

-- constraint add : mobile 중복불가, NULL 허용
alter table member 
add constraint UK_mobile unique (mobile);

-- detail : notice table
CREATE table NOTICE (
	notice_no number(8),
    title varchar2(30) not null,
    contents varchar2(500),
    MEMBER_ID varchar2(30),
    write_date date not null,
    hit_count number(10)
);

-- constraint add : pk
alter table notice
add CONSTRAINT PK_NOTICE_notice_no PRIMARY KEY (notice_no);

-- constraint add : fk
alter table notice
add constraint fk_memberid foreign key (MEMBER_ID) references member(member_id);


-- drop sequence
drop sequence seq_notice;


-- create sequence : notice_no
create sequence seq_notice
start with 1
increment by 1
;


-- init insert : memberde
insert into member(member_id, member_pw, name, mobile, email, entry_date, grade, mileage)
values('user01', 'password01', '홍길동', '010-1234-1111', 'user01@work.com	', '2017.05.05', 'G', 7500);

insert into member
values('user02', 'password02', '강감찬', '010-1234-1112', 'user02@work.com', '2017.05.06', 'G', 95000, null);

insert into member
values('user03', 'password03', '이순신', '010-1234-1113', 'user03@work.com', '2017.05.07', 'G', 3000, null);

insert into member
values('user04', 'password04', '김유신', '010-1234-1114', 'user04@work.com', '2017.05.08', 'S', null, '송중기');

insert into member
values('user05', 'password05', '유관순', '010-1234-1115', 'user05@work.com', '2017.05.09', 'A', null, null);

-- db 반영
commit;

-- init insert : notice
insert into notice
values(seq_notice.nextval, '주말과제', '회원도서관리DB설계', 'user05', '2020.11.11', 0);

insert into notice
values(seq_notice.nextval, '형상관리', '형상관리 소개', 'user04', '2020.12.25', 5);

insert into notice
values(seq_notice.nextval, '주말과제', '화면정의서', 'user05', '2021.02.14', 0);

insert into notice
values(seq_notice.nextval, '과제제출', '시간엄수', 'user05', '2021.03.01', 15);

insert into notice
values(seq_notice.nextval, 'WEB참고', 'www.w3schools.com', 'user01', '2021.05.26', 5);

-- db 반영
commit;



















